import os

# Get the current directory
directory = os.path.dirname(os.path.abspath(__file__))

# Iterate through all files in the directory
for filename in os.listdir(directory):
    # Check if the file matches the pattern "ChatGPT-X.mhtml"
    if filename.startswith("ChatGPT-") and filename.endswith(".mhtml"):
        # Extract the number from the filename
        number = filename.split("-")[1].split(".")[0]
        
        # Create the new filename
        new_filename = f"ChatGPT 3.5-{number}.mhtml"
        
        # Construct full file paths
        old_path = os.path.join(directory, filename)
        new_path = os.path.join(directory, new_filename)
        
        # Rename the file
        os.rename(old_path, new_path)
        print(f"Renamed: {filename} -> {new_filename}")

print("Renaming complete.")