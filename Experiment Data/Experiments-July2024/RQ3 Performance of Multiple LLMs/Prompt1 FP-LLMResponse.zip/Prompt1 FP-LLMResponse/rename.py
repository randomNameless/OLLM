import os
import re

def rename_files_in_directory(directory):
    # Regular expression to match the pattern ending with a number followed by the file extension
    pattern = re.compile(r'(.*?)(\d+)(\.\w+)$')

    # List all files in the directory
    for filename in os.listdir(directory):
        # Match the pattern in the filename
        match = pattern.match(filename)
        if match:
            base_name = match.group(1)  # The part before the number
            number = int(match.group(2))  # The number part
            extension = match.group(3)  # The file extension
            new_number = number - 4  # Subtract 4 from the number

            # Create the new filename
            new_filename = f"{base_name}{new_number}{extension}"
            
            # Get the full paths
            old_file = os.path.join(directory, filename)
            new_file = os.path.join(directory, new_filename)
            
            # Rename the file
            os.rename(old_file, new_file)
            print(f"Renamed: {filename} -> {new_filename}")

# Example usage
directory_path = '.'  # Current directory
rename_files_in_directory(directory_path)
